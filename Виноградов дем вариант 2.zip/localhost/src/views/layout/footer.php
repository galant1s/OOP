</div>

<script src="/src/front/js/classes/validator.js"></script>
<script src="/src/front/js/classes/toast.js"></script>
</body>
</html>