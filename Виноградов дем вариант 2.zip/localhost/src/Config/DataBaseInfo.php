<?php

// Возврат всех данных Базы данных

return [
    'adapter'   =>  'mysql',
    'host'      =>  'localhost',
    'user'      =>  'root',
    'password'  =>  'root',
    'dbname'    =>  'dem',
    'charset'   =>  'utf8'
];