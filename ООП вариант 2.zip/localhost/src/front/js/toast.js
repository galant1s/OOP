class Toast {

    constructor(name,content,classCss) {
        this.name = name;
        this.content = content;
        this.classCss = classCss;
    }

    show() {
        $('.toasts').append(
            "<div class="+this.name+" "+this.classCss +">" +
                "<span>"+this.content+"</span>" +
            "</div>");
        setTimeout(this.hide(),5000);
    }

    hide() {
        $("."+this.name).remove();
    }
}