let success = new Toast('valid','Вы зарегистрировались','success');

$('#reg').on('click',function (event){
    event.preventDefault();

    let name = $('.input[name=name]').val();
    let login = $('.input[name=login]').val();
    let email = $('.input[name=email]').val();
    let password = $('.input[name=pass]').val();
    let repassword = $('.input[name=repass]').val();
    let check = $('.input[name=check]');

    if (name === '' || login === '' || email === '' || password === '' || repassword === '' || check.prop('checked') == false) {
        let toast = new Toast('nameValid','Заполните поля','error');
        toast.show();
        console.log('Заполните поля')
    } else {
        let valid  = /^[А-ЯЁ\s-]+$/i;
        let res = valid.test(name);
        if (res == false) {
            let toast = new Toast('nameValid','Введите только руссие буквы, пробелы, дефисы','error');
            toast.show();
            console.log('Введите только руссие буквы, пробелы, дефисы');
        } else {
            valid = /[A-Z.]/i;
            res = valid.test(login);
            if (res == false) {
                new Toast('loginValid','Введите только английские буквы и точки','error').show();
                console.log('Введите только английские буквы и точки')
            } else {
                if (password == repassword) {
                    $.ajax({
                        url: '/registration.php',
                        method: 'post',
                        data: {name:name,login:login,email:email,password:password},
                        success: success
                    });
                } else {
                    new Toast('passwordValid','Пароли не совпадают','error').show();
                    console.log('Пароли не совпадают')
                }
            }
        }
    }   
    function success(data) {
        console.log(data);
    }

    return false;
});