<?php

use MasterOk\Controllers\LoginController;
use MasterOk\Controllers\ViewController;

return [
    'view'  =>  ViewController::class,
    'login' =>  LoginController::class
];