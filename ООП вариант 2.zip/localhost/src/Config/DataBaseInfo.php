<?php

return [
    'adapter'   =>  'mysql',
    'host'      =>  'localhost',
    'user'      =>  'root',
    'password'  =>  'root',
    'dbname'    =>  'dem',
    'charset'   =>  'utf8'
];