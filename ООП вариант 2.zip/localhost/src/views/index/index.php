<h1>Последние заявки</h1>
<h2>Всего заявок:</h2>
<hr>
<h3>Создай аккаунт прямо сейчас</h3>
<div class="row">
    <div id="registr">
        <div class="form-container">
            <input type="text" class="input" name="name" placeholder="Введите ФИО" required>
            <input type="text" class="input" name="login" placeholder="Введите логин" required>
            <input type="email" class="input" name="email" placeholder="Введите почту" required>
            <input type="password" class="input" name="pass" placeholder="Введите пароль" required>
            <input type="password" class="input" name="repass" placeholder="Повторите пароль" required>
            <input type="checkbox" class="input" name="check" required><label for="check">Подтвердите согласие на обработку</label>
            <button id="reg">Зарегистрироваться</button>
        </div>
    </div>
    <div id="login">
        <div class="form-container">
            <input type="text" name="login" placeholder="Введите логин" required>
            <input type="password" name="pass" placeholder="Введите пароль" required>
            <button>Авторизироваться</button>
        </div>
    </div>
</div>