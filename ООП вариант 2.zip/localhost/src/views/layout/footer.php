<div class="toasts">

</div>
<script src="/src/front/js/toast.js"></script>
<script src="/src/front/js/formslayer.js"></script>
</body>
</html>